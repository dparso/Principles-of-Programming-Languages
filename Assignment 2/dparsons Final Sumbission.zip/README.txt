Dylan Parsons
CS 2320
10/05/17

Usage: $python dparsons.py someInput.txt

Information:
stack is a variable to keep track of the recursion; if something causes an error, it’ll print the current path.

Known Bugs: N/A. Multiple statements between an “if” and “else” segment will be marked as incorrect, but this follows from the production rule for “if”.